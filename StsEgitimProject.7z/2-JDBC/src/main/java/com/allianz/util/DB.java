package com.allianz.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DB {
	
	private final String url = "jdbc:mysql://localhost/allianz_spring?useUnicode=true&characterEncoding=utf-8"; //allianz_spring db name
	private final String uName = "root";
	private final String uPass = "";
	private final String driver = "com.mysql.jdbc.Driver"; //dependency altında
	
	private Connection conn = null;
	private PreparedStatement pre = null;
	
	public DB() {
		
		try {
			Class.forName(driver); //??
			conn = DriverManager.getConnection(url, uName, uPass);
			System.out.println("Connected");
		}catch (Exception e) {
			System.err.println("Connect Error: " + e);
		}
		
	}
	
	//pre
	public PreparedStatement preFnc(String query) {
		try {
			pre = conn.prepareStatement(query);
		} catch (Exception e) {
			System.err.println("PreparedStatement error: " + e);
		}
		return pre;
	}
	
	

}
