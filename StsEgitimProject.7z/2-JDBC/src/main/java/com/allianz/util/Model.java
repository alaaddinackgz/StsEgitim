package com.allianz.util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Model {

	DB db = new DB();
	
	
	//database insert
	public int insert(NoteProps note)
	{
		try {
			String query = "INSERT INTO `notes` (`nid`, `ntitle`, `ndetail`, `ndate`) VALUES (NULL, ?, ?, now());";
			PreparedStatement pre = db.preFnc(query);
			pre.setString(1, note.getNtitle());
			pre.setString(2, note.getNdetail());
		    return pre.executeUpdate();
		} catch (Exception e) {
			System.err.println("insert Error: " + e);
		}
		return -1;
	}	
	
	
	//database select
	public List<NoteProps> list() {
		List<NoteProps> ls = new ArrayList<NoteProps>();
		
		try {
			String query = "select * from notes";
			PreparedStatement pre = db.preFnc(query);
			ResultSet rs = pre.executeQuery();
			
			while(rs.next()) {
				NoteProps nt = new NoteProps();
				
				nt.setNid(rs.getInt("nid"));
				nt.setNtitle(rs.getString("ntitle"));
				nt.setNdetail(rs.getString("ndetail"));
				nt.setNdate(rs.getTimestamp("ndate"));
				ls.add(nt);
				
				
			}
			
		} catch (Exception e) {
			System.err.println("List Error : " + e);
		}
		
		return ls;
	}
	
	//delete item
	public int delete(int nid) {
		try {
			String query = "delete from notes where nid = ?";
			PreparedStatement pre = db.preFnc(query);
			pre.setInt(1, nid);
			return pre.executeUpdate(); //döndüğü değer etkilenen kayıt sayıs(insert,update,delete aynı)
		} catch (Exception e) {
			System.err.println("Delete Error: " + e);
		}
		return -1;
		
	}
	
	public NoteProps single(int nid) {
		NoteProps nt = new NoteProps();
		try {
			String query = "select * from notes where nid = ?";
			PreparedStatement pre = db.preFnc(query);
			pre.setInt(1, nid);
			ResultSet rs = pre.executeQuery();
			if(rs.next()) {
				nt.setNid(rs.getInt("nid"));
				nt.setNtitle(rs.getString("ntitle"));
				nt.setNdetail(rs.getString("ndetail"));
				nt.setNdate(rs.getTimestamp("ndate"));
				
			}
		} catch (Exception e) {
			System.err.println("single error: " + e);
		}
		
		
		return nt;
	}
	
	
}
