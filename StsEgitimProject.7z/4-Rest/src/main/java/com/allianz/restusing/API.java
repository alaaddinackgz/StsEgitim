package com.allianz.restusing;

import java.net.InetSocketAddress;
import java.net.Proxy;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class API {

	private static Retrofit retrofit = null;

    public static Retrofit getClient() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        //OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("195.87.49.10", 8080));
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder().proxy(proxy);
        
        httpClient.addInterceptor(logging);

        if (retrofit != null) {
            retrofit = null;
        }

        //herhangi bir json tüketeceğimiz zaman sadece baseurl değiştirmemiz yeterli
        //her yerde bu api kullanılabilir
        retrofit = new Retrofit.Builder()
                .baseUrl("http://jsonbulut.com/json/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(httpClient.build())
                .build();

        return retrofit;
    }

	
}
