package com.allianz.util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Model {

	DB db = new DB();

	// db insert
	public int insert(NoteProps note) {
		try {
			String query = "INSERT INTO `notes` (`nid`, `ntitle`, `ndetail`, `ndate`) VALUES (NULL, ?, ?, now());";
			PreparedStatement pre = db.preFnc(query);
			pre.setString(1, note.getNtitle());
			pre.setString(2, note.getNdetail());
			return pre.executeUpdate();
		} catch (Exception e) {
			System.err.println("Insert Error :" + e);
		}
		return -1;
	}

	// db select
	public List<NoteProps> list() {
		List<NoteProps> ls = new ArrayList<NoteProps>();

		try {
			String query = "Select * from notes";
			PreparedStatement pre = db.preFnc(query);
			ResultSet rs = pre.executeQuery();
			while (rs.next()) {
				NoteProps nt = new NoteProps();
				nt.setNid(rs.getInt("nid"));
				nt.setNtitle(rs.getString("ntitle"));
				nt.setNdetail(rs.getString("ndetail"));
				nt.setNdate(rs.getDate("ndate"));
				ls.add(nt);
			}
		} catch (Exception e) {
			System.err.println("List Error: " + e);
		}

		return ls;
	}

	public int delete(int nid) {
		try {
			String query = "delete from notes where nid = ?";
			PreparedStatement pre = db.preFnc(query);
			pre.setInt(1, nid);
			return pre.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println("Delete Error : " + e);
		}
		return -1;
	}

	public NoteProps single(int nid) {
		NoteProps nt = new NoteProps();

		try {
			String query = "select * from notes where nid = ?";
			PreparedStatement pre = db.preFnc(query);
			pre.setInt(1, nid);
			ResultSet rs = pre.executeQuery();
			if (rs.next()) {
				nt.setNid(rs.getInt("nid"));
				nt.setNtitle(rs.getString("ntitle"));
				nt.setNdetail(rs.getString("ndetail"));
				nt.setNdate(rs.getDate("ndate"));
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.err.println("Update Errror :  " + e);
		}

		return nt;
	}

	public int fncUpdate(NoteProps note) {
		try {
			String query = "update notes set ntitle= ?, ndetail= ? where nid= ? limit 1";
			PreparedStatement pre = db.preFnc(query);
			pre.setString(1, note.getNtitle());
			pre.setString(2, note.getNdetail());
			pre.setInt(3, note.getNid());
			return pre.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println("Update Error : " + e);
		}
		return -1;
	}

	//admin login
	public int adminLogin(AdminProps adm, HttpServletRequest req,HttpServletResponse res) {
		//System.out.println("rememeber"+adm.getRemember_me());
		try {
			String query = "select * from admin where amail = ? and apass = ?";
			PreparedStatement pre = db.preFnc(query);
			pre.setString(1, adm.getAmail());
			pre.setString(2, MD5(adm.getApass()));

			ResultSet rs = pre.executeQuery();
			if (rs.next()) {
				adm.setAname(rs.getString("aname"));
				req.getSession().setAttribute("user", adm);
				
				if(adm.getRemember_me() != null) {
					//create cookie
					Cookie cookie = new Cookie("user_cookie", rs.getString("aname"));
					cookie.setMaxAge(60*60*24); //ne zaman ölecek
					res.addCookie(cookie);
				}
				
				return 0;
			} else {
				//login fail
				return 1;
			}

		} catch (Exception e) {
			System.err.println("Login error" + e);
		}
		return -1;
	}

	public String MD5(String md5) {
		try {
			java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
			byte[] array = md.digest(md5.getBytes());
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < array.length; ++i) {
				sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
			}
			return sb.toString();
		} catch (java.security.NoSuchAlgorithmException e) {
		}
		return null;
	}
	
	//admin sessiion conrol
	/**
	 * Admin login control method
	 * return: String
	 * return -> goto page name
	 */
	//staticler program içeriisnde her yerden ulaşılıp her yerde değiştirilebilir
	public static String control(HttpServletRequest req,String page) {
		
		//daha önce ürettiğimiz cookie user_cookie
				//user_cookie bizim domain altında olan cookie
				//session'ı silip sayfayı güncelledikten sonra cookie oldugu için aynı sayfada kalıyoruz
		//session kapansa bile beni hatırla ile cookie'den bilgiyi alıp login sayfasına atmıyor		
		if (req.getCookies() != null) {
					Cookie[] arr = req.getCookies();
					for (Cookie item : arr) {
						if(item.getName().equals("user_cookie")) {
							String name = item.getValue();
							AdminProps adm = new AdminProps();
							req.getSession().setAttribute("user",adm);
						}
						
					}
				}
		
		boolean statu = req.getSession().getAttribute("user") == null;
		if (statu) {
			return "redirect:/login"; //redirect browserda isminde değişmesini sağlar
		}
		
		return page;
	}
	
	
}
