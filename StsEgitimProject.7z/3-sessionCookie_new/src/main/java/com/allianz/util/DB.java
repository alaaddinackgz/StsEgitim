package com.allianz.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DB {
	
	private final String url = "jdbc:mysql://localhost/allianz_spring?useUnicode=true&characterEncoding=utf-8";
	private final String uName = "root";
	private final String uPass = "";
	private final String driver = "com.mysql.jdbc.Driver";
	
	private Connection conn = null;
	private PreparedStatement pre = null;
	
	public DB() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,uName,uPass);
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println("Connection error" + e);
		}
	}
	
	
	public PreparedStatement preFnc(String query) {
		try {
			pre = conn.prepareStatement(query);
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println("preparedStatement error : " + e );
		}
		return pre;
	}
	
}
