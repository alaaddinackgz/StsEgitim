package com.allianz.util;

public class AdminProps {

	private int aid;
	private String amail;
	private String apass;
	private String aname;
	private String remember_me;
	
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAmail() {
		return amail;
	}
	public void setAmail(String amail) {
		this.amail = amail;
	}
	public String getApass() {
		return apass;
	}
	public void setApass(String apass) {
		this.apass = apass;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getRemember_me() {
		return remember_me;
	}
	public void setRemember_me(String remember_me) {
		this.remember_me = remember_me;
	}
	
}
