package com.allianz.jdbc;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.allianz.util.DB;
import com.allianz.util.Model;
import com.allianz.util.NoteProps;

@Controller
public class DashboardController {
	
	Model ns = new Model();
	
	@GetMapping("/")
	public String dashboard(org.springframework.ui.Model model, HttpServletRequest req) {
		
		/*boolean statu = req.getSession().getAttribute("user") == null;
		if(statu) {
			return "redirect:/login";
		}*/
		model.addAttribute("ls",ns.list());
		
		return Model.control(req, "dashboard"); //"dashboard";
	}
	
	//insert
	@PostMapping("/insert")
	public String fncInsert(NoteProps note) {
		ns.insert(note);
		return "redirect:/";
	}
	
	@GetMapping("/delete/{nid}")
	public String fncDelete ( @PathVariable int nid ) {
		ns.delete(nid);
		return "redirect:/";
	}
	
	NoteProps notePro = new NoteProps();
	@GetMapping("/getUpdate/{nid}")
	public String fncGetUpdate(org.springframework.ui.Model model , @PathVariable int nid,HttpServletRequest req) {
		model.addAttribute("ls", ns.list());
		notePro = ns.single(nid);
		model.addAttribute("ns", notePro);
		
		return Model.control(req, "dashboard"); //"dashboard";
	}
	
	@PostMapping("/updateSave")
	public String updateSave(NoteProps nt) {
		nt.setNid(notePro.getNid());
		ns.fncUpdate(nt);
		return "redirect:/";
	}
}
