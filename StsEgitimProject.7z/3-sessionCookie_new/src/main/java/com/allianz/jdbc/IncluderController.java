package com.allianz.jdbc;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.allianz.util.AdminProps;
import com.allianz.util.Model;

@Controller
public class IncluderController {

	@GetMapping("/header") //header ile inc/headr'a erişecek
	public String header(HttpServletRequest req, org.springframework.ui.Model model) {
		
		AdminProps adm = (AdminProps)req.getSession().getAttribute("user");
		model.addAttribute("adm", adm);
		return Model.control(req, "inc/header");
	}
	
	
}
