package com.allianz.jdbc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.allianz.util.AdminProps;
import com.allianz.util.Model;

@Controller
public class LoginController {
	
	Model md = new Model();
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@PostMapping("/loginAdmin")
	public String loginAdmin(AdminProps adm, HttpServletRequest req,HttpServletResponse res) {
		if(md.adminLogin(adm, req,res) == 0) {
			return "redirect:/";
		}
		return "login";
	}
	
	//exit fnc
	@GetMapping("/exit")
	public String exit(HttpServletRequest req) {
		//single session delete
		req.getSession().removeAttribute("user"); //user'a ait session'ı sil
		//all session delete
		req.getSession().invalidate();
		return "redirect:/login";
	}
	
	
	
}
