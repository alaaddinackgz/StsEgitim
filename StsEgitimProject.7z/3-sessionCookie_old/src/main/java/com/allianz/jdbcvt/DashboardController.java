package com.allianz.jdbcvt;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.allianz.util.DB;
import com.allianz.util.Model;
import com.allianz.util.NoteProps;

//Sınıfın çaıştıktan sonra bir sınıfın methodlarını çağırmasını istiyorsak Controller gerekir
//web service ise yazmasakda olur
@Controller 
public class DashboardController {

	Model ns = new Model();
	
	//reuestmappin,postmapping kullanmıştık. Getmapping kullanımı
	@GetMapping("/")
	public String dashboard(org.springframework.ui.Model model) { //org.springframework.ui.
		System.out.println("size: " + ns.list().size());
		
		model.addAttribute("ls", ns.list());
		return "dashboard";
	}
	
	
	//insert
	@PostMapping("/insert") // /insert jspde value ile aynı olmaı
	public String fncInsert(NoteProps note) {
		ns.insert(note);
		return "redirect:/"; //dashboard.  redirect özel bir kelime, normalde dashboardu arar fakat redirect de aramaz
		
	}
	
	//jsp içinde <a href işlemlerinşn hepsi get ile çalışır,post olmaz
	//delete
	@GetMapping("/delete/{nid}")
	public String fncDelete(@PathVariable int nid) { //Form ile gönderilseydi @RequestParam kullanabilirdik
		ns.delete(nid);
		return "redirect:/";
		

	}
	
/*
 * jsp içerisinde pop-up (emin misin) açmak için yazılıyor
 * 
 * <script>
	function alertFnc(){
		var statu = confirm("Silmek istediğinizden emin misiniz?");
		return statu
		}

</script>
 *<a onclick="return alertFnc()" href='<s:url value="/delete/${item.nid}"></s:url>' class="btn btn-danger">Delete</a>
 */
	
	//delete
		@GetMapping("/getUpdate/{nid}")
		public String fncGetUpdate(org.springframework.ui.Model model, @PathVariable int nid) { 
			model.addAttribute("ls", ns.list());
			model.addAttribute("ns", ns.single(nid));
			return "dashboard";
			

		}
		
	
	
	
}
