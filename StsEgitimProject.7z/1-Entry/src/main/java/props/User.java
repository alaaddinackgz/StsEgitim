package props;

public class User {
	
	//home.jsp içeriside input değişkenleri ile name'ler aynı olduğu için 
	//otomatik olarak eşleştiriyor
	//default olarak bir constructer bulunuyor, parametreli olarak eklersen patlar
	//prametresiz constructer eklersen de çalışır
	private String userName;
	private String userSurname;
	private String userMail;
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserSurname() {
		return userSurname;
	}
	public void setUserSurname(String userSurname) {
		this.userSurname = userSurname;
	}
	public String getUserMail() {
		return userMail;
	}
	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	
	
	

}
