package com.allianz.entry;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import props.User;

@Controller
public class HomeController {
	
	List<String> ls = new ArrayList<>();
	List<User> uls = new ArrayList<>();
	
	public HomeController() {
		ls.add("Ali");
		ls.add("Veli");
		System.out.println("HomeController call");
	}
	
    @RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Random rnd, Model model) { //jsp data ile besleyeceğimiz zaman Model tanımlanr.Model ile jsp dosyasını besleyeceğim
    	System.out.println("calistim");
    	
    	System.out.println("Rdn: " +rnd.nextFloat());
    	System.out.println("ls: " +ls);
    	
    	//export data
    	model.addAttribute("dataKey", "Şampiyon Türkiye"); //homejsp içerisinde ${ dataKey } 
    	model.addAttribute("keyData", "Şampiyon FenerBahçe"); 
		return "home";
	}
    
    
    //post form pull data
    //s:url kullandık
    //@RequestParam da String,home.jspde input içindeki username ile aynı olmalı
    @PostMapping("/userForm") // @RequestMapping(value = "/", method = RequestMethod.GET) gibi tanımlama yapmak istemezsek böylede yapılabilir
    public String formData(
    		 				User us, Model model 
    //requestparam yerine çok fazla değişken için property classı oluşturduk ve değerleri alıyoruz
    						/* @RequestParam String userName,
    					   @RequestParam String userSurname,
    					   @RequestParam String userMail*/
    					   ) {
    	//System.out.println("user name: " +userName);
    	//System.out.println("user name: " +userSurname);
    	//System.out.println("user name: " +userMail);
    	uls.add(us);
    	System.out.println("userName: "+ us.getUserName());
    	model.addAttribute("uls", uls); //yığın bilgisini al diğer tarafa aktar. Liste içi doluyor,model ile taşıyacağız
    	return "home";
    	
    }
    
    
    
    
    

} 