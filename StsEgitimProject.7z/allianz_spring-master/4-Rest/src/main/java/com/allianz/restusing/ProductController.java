package com.allianz.restusing;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.allianz.model.Bilgiler;
import com.allianz.model.JsonData;

import retrofit2.Call;

@Controller
public class ProductController {

	@GetMapping("/")
	public String allProduct(Model model) {
		
		try {
			Service service = API.getClient().create(Service.class);
			Call<JsonData> dt = service.allProduct();
			List<Bilgiler> bl =  dt.execute().body().getProducts().get(0).getBilgiler();
			model.addAttribute("bl", bl);
			
		} catch (Exception e) {
			System.err.println("service error : " + e);
		}
		
		return "product";
	}
	
}
