package com.allianz.restusing;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class DBUtil {
	
	@Bean(name = "db")
	public DriverManagerDataSource source() {
		DriverManagerDataSource dt = new DriverManagerDataSource();
		dt.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dt.setUrl("jdbc:mysql://localhost/allianz_spring?useUnicode=true&characterEncoding=utf-8&serverTimezone=UTC");
		dt.setUsername("root");
		dt.setPassword("");
		return dt;
	}
	

}
