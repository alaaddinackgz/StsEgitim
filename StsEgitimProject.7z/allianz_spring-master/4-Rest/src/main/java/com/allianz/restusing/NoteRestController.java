package com.allianz.restusing;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class NoteRestController {
	
	@Autowired DriverManagerDataSource db;
	
	@GetMapping(value = { "/allNote/{number}", "/allNote" })
	public Map<String, Object> allNote( @PathVariable Optional<Integer> number ) {
		int num = 0;
		if (number.isPresent()) {
			num = number.get();
		}else {
			num = 10;
		}
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("statu", true);
		hm.put("message", "İşlem başarılı");
		hm.put("notes", notes(num));
		return hm;
	}
	
	
	private List<NoteProps> notes(int number) {
		List<NoteProps> ls = new ArrayList<NoteProps>();
		try {
			String query = "select * from notes limit 0 , " + number;
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while(rs.next()) {
				NoteProps pr = new NoteProps();
				pr.setNid(rs.getInt("nid"));
				pr.setNtitle(rs.getString("ntitle"));
				pr.setNdetail(rs.getString("ndetail"));
				pr.setNdate(rs.getTimestamp("ndate"));
				ls.add(pr);
			}
		} catch (Exception e) {
			System.err.println("List Error : " + e);
		}
		return ls;
	}
	
	
	
	// admin login service
	AdminProps admPro = new AdminProps();
	@PostMapping("/adminLogin")
	public Map<String, Object> admLogin( AdminProps adm ) {
		Map<String, Object> hm = new HashMap<String, Object>();
		int returnStatu = adminLogin(adm);
		if (returnStatu == 0) {
			// login success
			hm.put("statu", true);
			hm.put("message", "Admin login success");
			hm.put("user", admPro);
		}else {
			// login fail!
			hm.put("statu", false);
			hm.put("message", "Admin login fail!");
		}
		return hm;
	}
	
	
	
	
	
	public int adminLogin(AdminProps adm) {
		//System.out.println("rememeber : " + adm.getRemember_me());
		try {
			String query = "select * from admin where amail = ? and apass = ?";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			pre.setString(1, adm.getAmail());
			pre.setString(2, MD5(adm.getApass()));
			ResultSet rs = pre.executeQuery();
			if(rs.next()) {
				adm.setAname(rs.getString("aname"));
				admPro = adm;
				// admin login					
				return 0;
			}else {
				// login fail
				return 1;
			}
		} catch (Exception e) {
			System.err.println("login error : " + e);
		}
		return -1;
	}

	
	public String MD5(String md5) {
		try {
			java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
			byte[] array = md.digest(md5.getBytes());
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < array.length; ++i) {
				sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
			}
			return sb.toString();
		} catch (java.security.NoSuchAlgorithmException e) {
		}
		return null;
	}
	

}
