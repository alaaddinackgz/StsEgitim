package com.allianz.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.allianz.repomodel.Cars;

@Repository
public interface CarsRepository extends JpaRepository<Cars, Long>{

}
