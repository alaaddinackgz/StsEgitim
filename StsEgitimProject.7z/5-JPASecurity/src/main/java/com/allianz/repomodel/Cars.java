package com.allianz.repomodel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="cars")
@EntityListeners(AuditingEntityListener.class)
public class Cars {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY) // otomatik sayaç
	private long cid;
	
	@Column(name="title")
	private String sTitle;
	
	@Column(name="cprice")
	private int cPrice;

	public long getCid() {
		return cid;
	}

	public void setCid(long cid) {
		this.cid = cid;
	}

	public String getsTitle() {
		return sTitle;
	}

	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}

	public int getcPrice() {
		return cPrice;
	}

	public void setcPrice(int cPrice) {
		this.cPrice = cPrice;
	}
	
	
	
	
}
