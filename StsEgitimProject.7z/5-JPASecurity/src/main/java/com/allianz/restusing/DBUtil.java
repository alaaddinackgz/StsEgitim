package com.allianz.restusing;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration //proje ayağa kalkmadan ayarları yapması içim (configrasyon)
@ComponentScan(basePackages = {"com.allianz.*"})
@PropertySource("classpath:application.properties")
public class DBUtil {
	
	@Value("${spring.datasource.url}") //propertyde bu değeri dbUrl'e set ettik
	private String dbUrl;
	
	@Value("${spring.datasource.username}") //propertyde bu değeri dbUrl'e set ettik
	private String dbUser;
	
	@Value("${spring.datasource.password}") //propertyde bu değeri dbUrl'e set ettik
	private String dbPass;
	
	@Bean(name="db") //autowired bean olmadan kullanılamaz
	public DriverManagerDataSource source() {
		DriverManagerDataSource dt = new DriverManagerDataSource();
		dt.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dt.setUrl(dbUrl);
		dt.setUsername(dbUser);
		dt.setPassword(dbPass);
		return dt;
	}

}
