package com.allianz.restusing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;


@SpringBootApplication
@EnableJpaAuditing
@EnableJpaRepositories(basePackages = {"com.allianz.repositories"}) //repolar repository altında
@EntityScan(basePackages = {"com.allianz.repomodel"})  //entity repomodel altında
@ComponentScan(basePackages = {"com.allianz.restusing"}) //componentrestusing altında --gerekli değil-- controller paketleri farklı paketlerde ise gerekli
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	   
}
