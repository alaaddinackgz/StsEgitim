package com.allianz.restusing;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.allianz.model.Bilgiler;
import com.allianz.model.JsonData;

import retrofit2.Call;

@Controller
public class ProductController {

	@Autowired
	DriverManagerDataSource db;
	
	@GetMapping("/")
	public String allProduct(Model model) {
		
		try {
			Service service = API.getClient(0).create(Service.class); //nesneyi ürettik,service interfaceleri içerisindeki metodları class haline çeviriyoruz
			Call<JsonData> dt = service.allProduct();
			List<Bilgiler> bl = dt.execute().body().getProducts().get(0).getBilgiler(); //dt.execute().body().getProducts().get(0) bilgiler kısmına kadar lan kısım (status,durum,bilgiler ilk sekme)
			
			model.addAttribute("bl",bl);
			
			//database işlemi ekliyoruz-yukarıdaki işlemden ayrı olarak
			sqlProduct(bl);
			
			/*
			bl.forEach(item-> {
				System.out.println("Title :"+ item.getProductName());
			}); //lamda- bir fonksiyonun başka bir fonksiyona parametre olarak gönderilmesi
			*/
		} catch (Exception e) {
		System.err.println("service error :" + e);
		}
		
		return "product";
	}

	
	//json'ı databasede product tablosuna dolduruyoruz
	private void sqlProduct(List<Bilgiler> bl) {
		
		String query = "insert into product values(?,?,?,?);";
		PreparedStatement pre=null;
		
		try {
			pre = db.getConnection().prepareStatement(query);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		for (Bilgiler item : bl) {
		try {
				
				pre.setInt(1, Integer.valueOf( item.getProductId())); //obje olsaydı toint olurdu,jsondan string eliyor
				pre.setString(2, item.getProductName());
				pre.setString(3, item.getPrice());
				pre.setNString(4, item.getPrice());
				
				pre.executeUpdate();
			
			
			
		} catch (Exception e) {
			System.err.println("Update Error :" + e);
		}
		}
	}
	
	
	
	
}
