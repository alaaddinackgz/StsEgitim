package com.allianz.restusing;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.post.model.Postdatum;
import com.allianz.repomodel.Cars;
import com.allianz.repositories.CarsRepository;

import retrofit2.Call;


@RestController  //json dönmesini istiyoruz
public class NoteRestController {

	//beanler autowired ile tetiklenir //db DBUtils classında bean(name=db)'den geliyor
	@Autowired
	DriverManagerDataSource db;
	
	@Autowired
	CarsRepository carsRepository; 
	
	@GetMapping(value= {"/allNote/{number}","/allNote"} )
	public Map<String,Object> allNote( @PathVariable Optional<Integer> number){ //Optinal java 8 ile geldi
		
		int num= 0;
		if(number.isPresent()) {
			num=number.get();
		}else {
			num=10;
		}
	
		//LinkedHashMap ve HashMap<>(); farkı olarak linked sıralı getirir
		
		Map<String,Object> hm = new LinkedHashMap<>(); //HashMap<>(); //hm'de sadece map'in özellikleri bulunur. String a = "asd"; burada a'nın değerini stirng belirler
		hm.put("statu", true);  				//statu true ise bilgilere bak
		hm.put("message","işlem Başarılı");
		hm.put("notes", notes(num));
		return hm;
	}
	
	
	private List<NoteProps> notes(Integer number){
		List<NoteProps> ls = new ArrayList<NoteProps>();
		try {
			String query = "select * from notes limit 0 ,"+number; //t-sql oldugu için limit 
			PreparedStatement pre = db.getConnection().prepareStatement(query); //autowired burada başlıyor
			ResultSet rs = pre.executeQuery();
			while (rs.next()) {
				NoteProps pr = new NoteProps();
				pr.setNid(rs.getInt("nid"));				//her sınıf object sınıfını miras alır
				pr.setNtitle(rs.getString("ntitle"));
				pr.setNdetail(rs.getString("ndetail"));
				pr.setNdate(rs.getTimestamp("ndate"));
				ls.add(pr);
			}
		
		} catch (Exception e) {
			System.err.println("List Error: "+ e);
		}
		return ls;
	}
	
	//admin login service
	AdminProps admPro =new AdminProps();
	
	@PostMapping("/adminLogin")
	public Map<String,Object> admLogin(AdminProps adm){
		Map<String,Object>  hm = new HashMap<String,Object>();
		int returnStatu = adminLogin(adm);
		if (returnStatu==0) {
			//login success
			hm.put("statu", true);
			hm.put("message", "Admin login success");
			hm.put("user", admPro);
		}else {
			//login fail!
			hm.put("statu", false);
			hm.put("message", "Admin login fail");
		}
		return hm;
	}
	
	
	//admin login
		public int adminLogin(AdminProps adm) {
			//System.out.println("rememeber"+adm.getRemember_me());
			try {
				String query = "select * from admin where amail = ? and apass = ?";
				PreparedStatement pre = db.getConnection().prepareStatement(query);
				pre.setString(1, adm.getAmail());
				pre.setString(2, MD5(adm.getApass()));

				ResultSet rs = pre.executeQuery();
				if (rs.next()) {
					adm.setAname(rs.getString("aname"));
					admPro = adm;
					return 0;
				} else {
					//login fail
					return 1;
				}

			} catch (Exception e) {
				System.err.println("Login error" + e);
			}
			return -1;
		}

		public String MD5(String md5) {
			try {
				java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
				byte[] array = md.digest(md5.getBytes());
				StringBuffer sb = new StringBuffer();
				for (int i = 0; i < array.length; ++i) {
					sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
				}
				return sb.toString();
			} catch (java.security.NoSuchAlgorithmException e) {
			}
			return null;
		}
	
		
	   //all post services
	@GetMapping("/allPost")
	   public Map<String,Object> allPost(){
		   Map<String,Object> hm = new HashMap();
		   Service service = API.getClient(1).create(Service.class);
		   Call<Postdatum> dt = service.allPosts();
		   try {
			   
			hm.put("post", dt.execute().body());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		   return hm;
		   
	   }
		
	
	//cars insert
	@PostMapping("/carsInsert")
	public Cars carsInsert(Cars cr) {
		return carsRepository.save(cr);
	}
	
	
}
