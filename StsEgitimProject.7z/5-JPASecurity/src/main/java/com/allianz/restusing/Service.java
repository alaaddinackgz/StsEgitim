package com.allianz.restusing;

import com.allianz.model.JsonData;
import com.allianz.post.model.Postdatum;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Service {

	//product services
	//https://www.jsonbulut.com/json/product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=1&count=2
	//url'in kalan kısmı API içerisinde(base url)
	//domain değişimi olursa sadece API içerisi değiştirmek yeterli-tek merkezli
	@GET("product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=1&start=0")
	Call<JsonData> allProduct();
	
	//all posts
	@POST("posts")
	Call<Postdatum> allPosts();
	
	
}
